import './App.css';
import CodeDoodle from './components/CodeDoodle'

function App() {
  return (
    <CodeDoodle />
  );
}

export default App;

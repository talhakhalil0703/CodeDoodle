// StackFrame info
export const STACK_FRAME_WIDTH = 400
export const STACK_FRAME_HEIGHT = 300